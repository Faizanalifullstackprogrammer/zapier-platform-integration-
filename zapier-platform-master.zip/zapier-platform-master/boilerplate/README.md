# Zapier Platform Boilerplate

Boilerplate is an empty Zapier integration project. We use it to build a zip
providing all the necessary dependencies for integrations developed on visual
builder.
