# HTTP Middleware Example App For Zapier Platform

[![Build Status](https://travis-ci.org/zapier/zapier-platform-example-app-middleware.svg?branch=master)](https://travis-ci.org/zapier/zapier-platform-example-app-middleware)

A simple app that demonstrates the use of HTTP before and after middleware.

> We recommend using the zapier-platform-cli and `zapier init . --template=middleware` to create an app.
