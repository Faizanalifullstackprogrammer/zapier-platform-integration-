# zapier-platform-example-app-github

An example app that helps kickstart your journey as a Zapier [developer](https://zapier.com/developer/). Once logged in, you can see the tutorial itself [here](https://zapier.com/developer/start/introduction).

You can learn more about the CLI [here](https://github.com/zapier/zapier-platform-cli).
