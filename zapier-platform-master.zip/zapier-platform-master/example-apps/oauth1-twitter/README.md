# "OAuth1" Twitter Example App For Zapier Platform

Requires CLI **7.5.0** and above! A barebones app that has OAuth1 setup, using Twitter for example.

> We recommend using the zapier-platform-cli and `zapier init . --template=oauth1-twitter` to create an app.
