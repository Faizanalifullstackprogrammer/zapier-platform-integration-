# HTTP Search Example App For Zapier Platform

[![Build Status](https://travis-ci.org/zapier/zapier-platform-example-app-search.svg?branch=master)](https://travis-ci.org/zapier/zapier-platform-example-app-search)

A simple app that demonstrates how to write a simple search action.

> We recommend using the zapier-platform-cli and `zapier init <path> --template=search` to create an app.
