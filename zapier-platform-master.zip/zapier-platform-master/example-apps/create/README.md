# "Create" Example App For Zapier Platform

[![Build Status](https://travis-ci.org/zapier/zapier-platform-example-app-create.svg?branch=master)](https://travis-ci.org/zapier/zapier-platform-example-app-create)

A barebones app that has a create defined.

> We recommend using the zapier-platform-cli and `zapier init . --template=create` to create an app.
