# "REST Hooks" Trigger Example App For Zapier Platform

[![Build Status](https://travis-ci.org/zapier/zapier-platform-example-app-rest-hooks.svg?branch=master)](https://travis-ci.org/zapier/zapier-platform-example-app-rest-hooks)

A barebones app that has a [REST Hook](https://resthooks.org) trigger defined.

> We recommend using the zapier-platform-cli and `zapier init . --template=rest-hooks` to create an app.
