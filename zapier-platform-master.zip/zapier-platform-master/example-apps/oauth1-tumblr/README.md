# "OAuth1" Tumblr Example App For Zapier Platform

Requires CLI **7.5.0** and above! A barebones app that has OAuth1 setup, using Tumblr for example.

> We recommend using the zapier-platform-cli and `zapier init . --template=oauth1-tumblr` to create an app.
