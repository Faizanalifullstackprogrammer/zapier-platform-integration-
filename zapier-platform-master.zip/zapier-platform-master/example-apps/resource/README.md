# "Resource" Example App For Zapier Platform

[![Build Status](https://travis-ci.org/zapier/zapier-platform-example-app-resource.svg?branch=master)](https://travis-ci.org/zapier/zapier-platform-example-app-resource)

A barebones app that has a resource defined.

> We recommend using the zapier-platform-cli and `zapier init . --template=resource` to create an app.
