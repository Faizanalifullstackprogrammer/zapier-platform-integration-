keep

- [ ] dynamic-dropdown
- [ ] files
- [ ] minimal
- [ ] search-or-create
- [ ] typescript

keep 1 file

- [x] basic-auth
- [x] custom-auth
- [x] digest-auth
- [x] oauth1-trello
- [x] oauth2
- [x] rest-hooks
- [x] session-auth

delete

- [ ] create
- [ ] middleware
- [ ] oauth1-tumblr
- [ ] oauth1-twitter
- [ ] resource
- [ ] search
- [ ] trigger

archive

- [ ] github
- [ ] onedrive

# Steps

1. Right now, create complete, texted examples in the `examples` dir
2. After end of calendar year 2019, can delete all `delete` items from above list
3. edit scaffold command to use the new examples; pin them to the release version
