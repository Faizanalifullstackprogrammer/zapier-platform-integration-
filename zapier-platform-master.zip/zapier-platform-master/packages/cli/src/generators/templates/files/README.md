# The "files" Template

This example has a trigger and a create showcasing file handling.

Find out more in the docs: https://github.com/zapier/zapier-platform/blob/master/packages/cli/README.md#stashing-files.
