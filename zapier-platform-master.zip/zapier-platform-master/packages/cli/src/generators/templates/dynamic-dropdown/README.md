# The "dynamic-dropdown" Template

This example integration uses the [Star Wars API](https://swapi.dev/) to provide a dynamic listing of choices for an `inputField` in a trigger.

![](https://cdn.zappy.app/d985065c5098089795d9b60c77791e12.png)
