# The "search-or-create" Template

An example showcasing a Search-or-Create.

![](https://cdn.zappy.app/5fc31d104c6bd0050c44510557b3b98f.png)
