# The "typescript" Template

This example is mainly a proof-of-concept for using features not yet available
in Node.

In `package.json`, we've define some commonly-used scripts:

```bash
# Watch and compile as you edit code
npm run watch

# There's also a non-watch compile command
npm run build

# To push to Zapier, make sure you compile first
npm run build && zapier push
```
