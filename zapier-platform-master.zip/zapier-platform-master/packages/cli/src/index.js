// for now, requiring this file has no real effect

module.exports = require('@oclif/command');
