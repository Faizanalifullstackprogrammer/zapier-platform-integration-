module.exports = (method) => {
  return method === 'firehoseWebhooks.performSubscriptionKeyList';
};
