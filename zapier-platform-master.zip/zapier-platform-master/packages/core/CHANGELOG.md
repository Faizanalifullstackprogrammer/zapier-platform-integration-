Read docs: https://zapier.github.io/zapier-platform/.

Changelog: https://github.com/zapier/zapier-platform/blob/master/CHANGELOG.md
