const integrationTest = require('../integration-test/integration-test');

integrationTest.doTest(integrationTest.runLocally);
