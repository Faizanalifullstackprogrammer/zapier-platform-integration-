'use strict';

const HTTPBIN_URL = 'https://httpbin.zapier-tooling.com';

module.exports = {
  HTTPBIN_URL,
};
