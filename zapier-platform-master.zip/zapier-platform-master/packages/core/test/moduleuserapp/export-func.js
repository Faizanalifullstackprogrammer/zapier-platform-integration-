module.exports = (z, bundle) => {
  return [{ id: 1234 }] || bundle;
};
