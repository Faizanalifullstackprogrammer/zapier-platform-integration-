Please open your issues on https://github.com/zapier/zapier-platform-cli/issues instead.

Also, we have a Slack room at https://zapier-platform-slack.herokuapp.com/ set up if you have any other questions.
